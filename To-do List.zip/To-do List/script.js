// console.log("Welcom To To-do List App ");
// if user Add notes, then add it in local storage.
showNotes();
let addbtn = document.getElementById("addbtn");
addbtn.addEventListener("click", function (e) {
  let addtext = document.getElementById("addtext");
  let notes = localStorage.getItem("notes");
  if (notes == null) {
    notesObj = [];
  } else {
    notesObj = JSON.parse(notes);
  }
  notesObj.push(addtext.value);
  localStorage.setItem("notes", JSON.stringify(notesObj));
  addtext.value = "";
  //   console.log(notesObj);
  showNotes();
});

function showNotes() {
  let notes = localStorage.getItem("notes");
  if (notes == null) {
    notesObj = [];
  } else {
    notesObj = JSON.parse(notes);
  }
  let html = "";
  notesObj.forEach(function (element, index) {
    html += `
        <div class="notecard my-2 mx-2 text-white border border-white" style="width: 18rem">
          <div class="card-body">
            <h3 class="card-title">List  ${index + 1}</h3>
            <hr class="text-white">
            <p class="card-text">${element}</p>
            <button id="${index}" onclick="deleteNote(this.id)" class="btn btn-warning">Remove List</button>
          </div>
        </div>`;
  });
  let notesElm = document.getElementById("notes");
  if (notesObj.length != 0) {
    notesElm.innerHTML = html;
  } else {
    notesElm.innerHTML = `Nothing to show! "Add a To-do List" Section above to add List`;
  }
}
// function to delete notes.
function deleteNote(index) {
  //   console.log("i am deleting", index);

  let notes = localStorage.getItem("notes");
  if (notes == null) {
    notesObj = [];
  } else {
    notesObj = JSON.parse(notes);
  }
  notesObj.splice(index, 1);
  localStorage.setItem("notes", JSON.stringify(notesObj));
  showNotes();
}
